package com.cognizant.truyum;

/**
 * @author t-Khader
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Welcome to Spring Core  Truyum application!");
	}
}
