/**
 * 
 */
package com.cognizant.truyum.model;

import java.util.Date;

/**
 * @author t-Khader
 *
 */
public class MenuItem {
	

	private long id;
    private String name;
	private float price;
	private boolean active;
	private Date dateOfLaunch;
	private String category;
	private boolean freeDelivery;
	
	public MenuItem() {
	
	}

	/**
	 * @param id
	 * @param name
	 * @param price
	 * @param active
	 * @param dateOfLaunch
	 * @param category
	 * @param freeDelivery
	 */
	public MenuItem(long id, String name, float price, boolean active,
			Date dateOfLaunch, String category, boolean freeDelivery) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.active = active;
		this.dateOfLaunch = dateOfLaunch;
		this.category = category;
		this.freeDelivery = freeDelivery;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * @param active
	 *            the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * @return the dateOfLaunch
	 */
	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}

	/**
	 * @param dateOfLaunch
	 *            the dateOfLaunch to set
	 */
	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category
	 *            the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the freeDelivery
	 */
	public boolean isFreeDelivery() {
		return freeDelivery;
	}

	/**
	 * @param freeDelivery
	 *            the freeDelivery to set
	 */
	public void setFreeDelivery(boolean freeDelivery) {
		this.freeDelivery = freeDelivery;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MenuItem [id=" + id + ", name=" + name + ", price=" + price
				+ ", active=" + active + ", dateOfLaunch=" + dateOfLaunch
				+ ", category=" + category + ", freeDelivery=" + freeDelivery
				+ "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31; 
		int result = 1; 
	
		result = (int) (prime * result + id); 
		return result;
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		
		MenuItem other = (MenuItem) obj;
		
		if (id != other.id)
			return false;
		if (name.equals(other))
			return false;
		
		return true;
	}
	

}
