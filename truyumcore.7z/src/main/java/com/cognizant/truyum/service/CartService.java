package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

/**
 * @author t-Khader
 *
 */
public class CartService {

	@Autowired
	CartDao cartDao;

	public void setCartdao(CartDao cartDao) {
		this.cartDao = cartDao;
	}

	public void addCartItem(long userid, long menuItemId) {

		cartDao.addCartItem(userid, menuItemId);

	}

	public List<MenuItem> getAllCartItems(long userid) throws CartEmptyException {

		return cartDao.getAllCartItems(userid);

	}

	public void removeCartItem(long userId, long menuitemid) {

		cartDao.removeCartItem(userId, menuitemid);

	}

}
