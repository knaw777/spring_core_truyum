package com.cognizant.truyum.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemServiceTest {

	MenuItemService menutItemServiceBean;
	CartService cartServiceBean;
	ClassPathXmlApplicationContext ctx;

	@Before
	public void setUp() throws Exception {
		ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		menutItemServiceBean = (MenuItemService) ctx.getBean("menutItemService");
		cartServiceBean = (CartService) ctx.getBean("cartService");

	}

	@Test
	public void testGetMenuItemListAdminSize() {

		List<MenuItem> menuItemList = menutItemServiceBean.getMenuItemListAdmin();
		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}
		assertEquals(5, menuItemList.size());

	}

	@Test
	public void testGetMenuItemListAdminContainsSandwich() {

		System.out.println("MenuListAdmin size : " + menutItemServiceBean.getMenuItemListAdmin().size());
		List<MenuItem> menuItemList = menutItemServiceBean.getMenuItemListAdmin();
		List<String> menuItems = new ArrayList<String>();

		for (int i = 0; i < menuItemList.size(); i++) {

			menuItems.add(i, menuItemList.get(i).getName());

		}

		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}

		assertEquals(5, menuItemList.size());
		assertTrue(menuItems.contains("Sandwich"));

	}

	@Test
	public void testGetMenuItemListCustomerSize() {

		List<MenuItem> menuItemList = menutItemServiceBean.getMenuItemListCustomer();
		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}
		assertEquals(3, menuItemList.size());

	}

	@Test
	public void testGetMenuItemListCustomerNotContainsFrenchFries() {

		List<MenuItem> menuItemList = menutItemServiceBean.getMenuItemListAdmin();
		List<String> menuItems = new ArrayList<String>();

		for (int i = 0; i < menuItemList.size(); i++) {

			menuItems.add(i, menuItemList.get(i).getName());

		}

		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}

		assertFalse(!menuItems.contains("French Fries"));

	}

	@Test
	public void testGetMenuItem() {

	
		MenuItem menuItem = menutItemServiceBean.getMenuItem(1);
		System.out.println("menuItem before change:" + menuItem);

		menuItem.setName("Fruit Juice");

		menutItemServiceBean.modifyMenuItem(menuItem);

		menuItem = menutItemServiceBean.getMenuItem(1);
		System.out.println("After change:" + menuItem);
		assertTrue(menuItem.getName().equals("Fruit Juice"));

	}

}
