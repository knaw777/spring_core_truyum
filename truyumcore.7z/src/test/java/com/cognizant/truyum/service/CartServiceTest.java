package com.cognizant.truyum.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

public class CartServiceTest {

	MenuItemService menutItemServiceBean;
	CartService cartServiceBean;
	ClassPathXmlApplicationContext ctx;

	@Before
	public void setUp() throws Exception {
		System.out.println("before");
		ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		menutItemServiceBean = (MenuItemService) ctx.getBean("menutItemService");
		cartServiceBean = (CartService) ctx.getBean("cartService");

	}

	@Test(expected = CartEmptyException.class)
	public void testGetAllCartItems() throws CartEmptyException {

		List<MenuItem> menuItemList = cartServiceBean.getAllCartItems(1);
		System.out.println("menuItemList :" + menuItemList);

	}

	@Test
	public void testAddCartItem() throws CartEmptyException {

		List<MenuItem> menuItemList;

		cartServiceBean.addCartItem(1, 1);
		menuItemList = cartServiceBean.getAllCartItems(1);
		System.out.println("menuItemList : " + menuItemList);

		List<String> menuItems = new ArrayList<String>();

		for (int i = 0; i < menuItemList.size(); i++) {

			menuItems.add(i, menuItemList.get(i).getName());

		}

		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}

		assertTrue(menuItems.contains("Sandwich"));

	}

	@Test
	public void testRemoveCartItem() throws CartEmptyException {

		List<MenuItem> menuItemList;

		cartServiceBean.addCartItem(1, 1);
		menuItemList = cartServiceBean.getAllCartItems(1);
		System.out.println("menuItemList : " + menuItemList);

		cartServiceBean.removeCartItem(1, 1);
		List<String> menuItems = new ArrayList<String>();

		for (int i = 0; i < menuItemList.size(); i++) {

			menuItems.add(i, menuItemList.get(i).getName());

		}

		for (MenuItem menuitem : menuItemList) {

			System.out.println("menuItem:" + menuitem);

		}

		assertTrue(!menuItems.contains("Sandwich"));

	}

}
